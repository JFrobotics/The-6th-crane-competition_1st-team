#include "chassis_control_task.h"
#include "cmsis_os.h"
#include "bsp_can.h"
#include "CAN_receive.h"
#include "main.h"
#include "bsp_delay.h"
/**
  * @brief          led��˸
  * @param[in]      argument: NULL
  * @retval         none
  */
void led_task(void const * argument)
{
	while (1)
  {
	HAL_GPIO_WritePin(GPIOH, GPIO_PIN_12, GPIO_PIN_RESET);
    osDelay(500);
	HAL_GPIO_WritePin(GPIOH, GPIO_PIN_12, GPIO_PIN_SET);
    osDelay(500);
  }
}
