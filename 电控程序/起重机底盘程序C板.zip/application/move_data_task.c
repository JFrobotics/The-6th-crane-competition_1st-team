#include "chassis_control_task.h"
#include "cmsis_os.h"
#include "bsp_can.h"
#include "CAN_receive.h"
#include "main.h"
#include "bsp_delay.h"
/**
  * @brief          ���ܵ��̿�����Ϣ
  * @param[in]      argument: NULL
  * @retval         none
  */
void move_data_task(void const * argument)
{
	while (1)
  {
			
      
		osDelay(2);
  }
}

